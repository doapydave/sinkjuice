<?php 
echo do_shortcode('<div style="position:relative;" id="lptv-5-6-wrapper">

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-4-300x120 -->
<div id="div-gpt-ad-1403222233029-3" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-3"); });
</script>
</div>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-5-300x120 -->
<div id="div-gpt-ad-1403222233029-4" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-4"); });
</script>
</div>
</div>

</div>'); 
?>
