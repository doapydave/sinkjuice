<div id="doaptopleftwing" class="leftpagewingad">
Doap Admin
</div>

<div id="doaptoprightwing" class="rightpagewingad">
Ads deactivated
</div>

