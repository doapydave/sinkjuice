<!-- Tecnologia-bottom-728x90px -->
<div id='div-gpt-ad-1403214977765-0' class="bottom-center-728x90">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403214977765-0'); });
</script>
</div>
