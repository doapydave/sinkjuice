<div id="leftad" class="banner_flotanteizq" style="loat:left;margin-left:-169px;background-color:#eee;height:600px;width:160px;top:321px;position:absolute;">
Doap Admin
</div>

<div id="rightad" class="banner_flotanteizq" style="float:left;margin-left:1012px;background-color:#eee;height:600px;width:160px;top:321px;position:absolute;">
Ads deactivated
</div>

