<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 300x250 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-6970273280466483"
     data-ad-slot="4819490661"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
