<div id="top-social-icons">

<a href=http://noticias.laprensa.com.ni><img class="laprensa-thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/laprensa-button-for-lptv.png" style="position:relative;left:-5px;width:100px;height:30px;margin-right:2px;-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;" alt=""></a>

<a href="https://www.facebook.com/laprensanicaragua?ref=hl"><img class="fb-thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/hefacebook.svg" style="width:30px;height:30px;margin-right:2px;-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;" alt="">
</a>

<a href=https://twitter.com/laprensa>
<img class="twitter-thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/hetwitter.svg" style="width:30px;height:30px;margin-right:2px;-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;" alt="">
</a>

<a href=https://www.youtube.com/user/laprensanicaragua1><img class="g-thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/hetyoutube.svg" style="width:30px;height:30px;margin-right:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;" alt=""></a>


<a href=http://doap.com></a><img class="g-thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/hetlinkedin.svg" style="width:30px;height:30px;margin-right:2px;-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;" alt=""></a>

<a href=http://noticias.laprensa.com.ni/wp-login.php?action=wordpress_social_authenticate&provider=Google&redirect_to=http%3A%2F%2Fnoticias.laprensa.com.ni%2Flogin><img class="g-thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/hetgoogleplus.svg" style="width:30px;height:30px;margin-right:4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;" alt=""></a>


</div>
