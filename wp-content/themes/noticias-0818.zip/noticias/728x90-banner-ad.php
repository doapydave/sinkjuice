<!-- LA_PRENSA_Portada_728x90_Superior -->
<div id='div-gpt-ad-1399587327178-0' style='width:728px; height:90px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1399587327178-0'); });
</script>
</div>
<!-- LA_PRENSA_Portada_728x90_Superior out-of-page -->
<div id='div-gpt-ad-1399587327178-0-oop'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1399587327178-0-oop'); });
</script>
</div>
