<div id="leftad" class="banner_flotanteizq" style="float:left;margin-left:-169px;background-color:#369;height:600px;width:160px;top:103px;position:absolute;">
<!-- Portada-Left-160x600 -->
<div id='div-gpt-ad-1403200779714-0' style='width:160px; height:600px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403200779714-0'); });
</script>
</div>
</div>

<div id="rightad" class="banner_flotanteizq" style="float:left;margin-left:1018px;background-color:#369;height:600px;width:160px;top:103px;position:absolute;">
<!-- Portada-Right-160x600 -->
<div id='div-gpt-ad-1403200779714-1' style='width:160px; height:600px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403200779714-1'); });
</script>
</div>
</div>

