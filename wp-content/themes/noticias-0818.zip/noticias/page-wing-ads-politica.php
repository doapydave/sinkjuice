<!-- Politica-Left-160x600px -->
<div id='div-gpt-ad-1403209466030-0' class='leftad'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403209466030-0'); });
</script>
</div>

<!-- Politica-Right-160x600px -->
<div id='div-gpt-ad-1403209466030-1' class='rightad'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403209466030-1'); });
</script>
</div>

