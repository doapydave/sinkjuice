<!-- 120x600-Top -->
<div id='div-gpt-ad-1403371468819-0' style='width:120px; height:600px; background-color:#eee;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403371468819-0'); });
</script>
</div>


<style>
#center-home-ad { background-image: url(/wp-content/uploads/sites/2/2014/06/doap-120x600-100x500.png); }
</style>
