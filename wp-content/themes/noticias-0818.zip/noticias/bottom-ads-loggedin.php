<div id="doap-bottom-center-ad" class="bottom-center-728x90-loggedin" title="Hiding ads to save bandwidth.">
ads disabled</div>
