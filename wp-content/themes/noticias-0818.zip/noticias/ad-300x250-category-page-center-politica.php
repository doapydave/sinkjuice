<!-- Politica-Top-300x250px -->
<div id='div-gpt-ad-1403209466030-4' class='center-home-ad' style="height:250px;width:300px;background-color:#369;">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403209466030-4'); });
</script>
</div>
