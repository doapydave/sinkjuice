<div style="max-width:200px;z-index:1000">
                        <img class="thumbnail" src="http://laprensa13.doap.us/wp-content/uploads/sites/2/2014/06/lptv-header-logo.png" style="max-width:200px;" alt="">
</div>
i
http://noticias.laprensa.com.ni/wp-content/uploads/sites/2/2014/06/footerlptv1-1024x129.jpg
