<div id="center-home-ad-2" style="width:120px;height:600px;background-color:#eee;border:1px solid #000;">

</div>

