<!-- Aqui-entre-nos-Left-160x600px -->
<div id='div-gpt-ad-1403217573777-1' class="leftad">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403217573777-1'); });
</script>
</div>

<!-- Aqui-entre-nos-Right-160x600px -->
<div id='div-gpt-ad-1403217573777-2' class="rightad">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403217573777-2'); });
</script>
</div>
