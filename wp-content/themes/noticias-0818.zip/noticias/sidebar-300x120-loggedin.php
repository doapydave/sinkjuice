<div style=position:relative;top:360px;left:0px;width:100%;>

<?php 
echo do_shortcode('
<div style="height:630px;width:300px;background-color:#eee;">
</div>
[doap_spacer size=442]
'); 
?>
</div>
