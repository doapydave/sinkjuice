<div id="topsidead" style="position:absolute;width:260px;height:90px;left:739px;top:4px;z-index:10000;overflow:visible;background-color:#eee;">
<script type='text/javascript'>
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
var gads = document.createElement('script');
gads.async = true;
gads.type = 'text/javascript';
var useSSL = 'https:' == document.location.protocol;
gads.src = (useSSL ? 'https:' : 'http:') + 
'//www.googletagservices.com/tag/js/gpt.js';
var node = document.getElementsByTagName('script')[0];
node.parentNode.insertBefore(gads, node);
})();
</script>


	<div id="exampleHTMLToPage_b" style="position: relative; z-index: 9999; width: 260px; height: 90px;top:-90px;">

<!-- LAPRENSA_Portada_Boton1_260x90 -->
		<div id='div-gpt-ad-1401741405522-0' style='width:260px; height:90px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1401741405522-0'); });
</script>
		</div>

	<iframe id="exampleHTMLToPage_expanded_media" src="https://s3-us-west-2.amazonaws.com/s3.laprensa.com.ni/home/ventas/dollar-desplegable/index.html" scrolling="no" frameborder="0" style="visibility: visible; overflow: hidden; border-style: none; "></iframe>

		<div id="expanded_close" style="position: absolute; cursor: pointer; opacity: 0; width: 124px; z-index: 6644;">
		<a href="javascript://" onclick="ExpandableBanners.display('exampleHTMLToPage', false)" style="outline: none;">
			<img id="expanded_closeimg" src="images/closebutton.jpg" alt="Close" border="0">
		</a>
		</div>
	</div>


</div>

