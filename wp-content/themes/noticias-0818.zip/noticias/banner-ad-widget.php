<div style="clear:both;"></div>
<div class="topleftad" id="div-gpt-ad-1399587327178-0"></div>
<div style="clear:both;"></div>

