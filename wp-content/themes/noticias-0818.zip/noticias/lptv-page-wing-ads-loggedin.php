<script type='text/javascript'>
(function() {
var useSSL = 'https:' == document.location.protocol;
var src = (useSSL ? 'https:' : 'http:') +
'//www.googletagservices.com/tag/js/gpt.js';
document.write('<scr' + 'ipt src="' + src + '"></scr' + 'ipt>');
})();
</script>

<script type='text/javascript'>
googletag.defineSlot('/11648707/LP_Portada_banner2(160x600)', [160, 600], 'div-gpt-ad-1398207914431-0').addService(googletag.pubads());
googletag.pubads().enableSyncRendering();
googletag.pubads().enableSingleRequest();
googletag.enableServices();
</script>

<div id="leftad" class="banner_flotanteizq" style="float:left;margin-left:-169px;background-color:#eee;height:600px;width:142px;top:3px;position:absolute;padding:5px;border:4px solid #000;">
Doap Admin
</div>

<div id="rightad" class="banner_flotanteizq" style="float:left;margin-left:1014px;background-color:#eee;height:600px;width:142px;top:3px;position:absolute;padding:5px;border:4px solid #000;">
Ads deactivated
</div>

