[doap_tab title="Autos"]<iframe src="//www.youtube.com/embed/videoseries?list=PL7U9BvQbPxA-f_EC11Oixz6dxRckwyFTb&amp;controls=1&amp;showinfo=0&amp;rel=0" height="240" width="425" allowfullscreen="" frameborder="0"></iframe>[/doap_tab] 

[doap_tab title="Alquilas"]<iframe src="//www.youtube.com/embed/videoseries?list=PLAwnUMfjjAK-khjA3SmBMZb2HQ9sjoVs9&amp;controls=1&amp;showinfo=0&amp;rel=0" height="240" width="425" allowfullscreen="" frameborder="0"></iframe>[/doap_tab] 

[doap_tab title="Empleo"]<iframe src="//www.youtube.com/embed/videoseries?list=PL7U9BvQbPxA-csNVHpD9WZelwCxFf1hS8&amp;controls=1&amp;showinfo=0&amp;rel=0" height="240" width="425" allowfullscreen="" frameborder="0"></iframe>[/doap_tab]

