<script type='text/javascript'>
googletag.cmd.push(function() {

/* promociones slots */
googletag.defineSlot('/11648707/Promociones-Top-728x90px', [728, 90], 'div-gpt-ad-1403219444117-6').addService(googletag.pubads());
googletag.defineSlot('/11648707/Promociones-Top-270x90', [270, 90], 'div-gpt-ad-1403219444117-4').addService(googletag.pubads());
googletag.defineSlot('/11648707/Promociones-Left-160x600px', [160, 600], 'div-gpt-ad-1403219444117-1').addService(googletag.pubads())
googletag.defineSlot('/11648707/Promociones-Right-160x600px', [160, 600], 'div-gpt-ad-1403219444117-2').addService(googletag.pubads());
googletag.defineSlot('/11648707/Promociones-bottom-728x90px', [728, 90], 'div-gpt-ad-1403219444117-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Promociones-Top-300x250px', [300, 250], 'div-gpt-ad-1403219444117-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Promociones-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403219444117-3').addService(googletag.pubads());

/* nacionales slots */
googletag.defineSlot('/11648707/Nacionales-Top-728x90px', [728, 90], 'div-gpt-ad-1403196057127-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nacionales-Top-270x90', [270, 90], 'div-gpt-ad-1403203008472-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nacionales-bottom-728x90px', [728, 90], 'div-gpt-ad-1403197158457-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nacionales-Left-160x600px', [728, 90], 'div-gpt-ad-1403196624432-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nacionales-Right-160x600px', [160, 600], 'div-gpt-ad-1403196955810-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nacionales-Top-300x250px', [300, 250], 'div-gpt-ad-1403201478352-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nacionales-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211182544-0').addService(googletag.pubads());

/* politica slots */
googletag.defineSlot('/11648707/Politica-Left-160x600px', [160, 600], 'div-gpt-ad-1403209466030-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-Right-160x600px', [160, 600], 'div-gpt-ad-1403209466030-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-Top-270x90', [270, 90], 'div-gpt-ad-1403209466030-3').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-Top-728x90px', [728, 90], 'div-gpt-ad-1403209349821-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-Top-300x250px', [300, 250], 'div-gpt-ad-1403209466030-4').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-bottom-728x90px', [728, 90], 'div-gpt-ad-1403209349821-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211357945-0').addService(googletag.pubads());

/* economia slots */
googletag.defineSlot('/11648707/Economia-Top-300x250px', [300, 250], 'div-gpt-ad-1403210392163-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-Top-728x90px', [728, 90], 'div-gpt-ad-1403210392163-6').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211432106-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-Left-160x600px', [160, 600], 'div-gpt-ad-1403210392163-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-Right-160x600px', [160, 600], 'div-gpt-ad-1403210392163-2').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-Top-270x90', [270, 90], 'div-gpt-ad-1403210392163-4').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-bottom-728x90px', [728, 90], 'div-gpt-ad-1403210392163-0').addService(googletag.pubads());

/* deportes slots */
googletag.defineSlot('/11648707/Deportes-Left-160x600px', [160, 600], 'div-gpt-ad-1403202333789-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Deportes-Right-160x600px', [160, 600], 'div-gpt-ad-1403202333789-2').addService(googletag.pubads());
googletag.defineSlot('/11648707/Deportes-bottom-728x90px', [728, 90], 'div-gpt-ad-1403202333789-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Deportes-Top-300x250px', [300, 250], 'div-gpt-ad-1403202333789-4').addService(googletag.pubads());
googletag.defineSlot('/11648707/Deportes-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211286576-0').addService(googletag.pubads());


googletag.pubads().enableSingleRequest();
googletag.enableServices();
});
</script>
