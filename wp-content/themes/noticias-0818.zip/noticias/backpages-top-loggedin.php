<div id="left-top-728-loggedin" class="doaplefttop" title="Hiding ads to save bandwidth.">ads off</div>

<div id="right-top-270-loggedin" class="doaprighttop" title="Hiding ads to save bandwidth."> ads deactivated</div>
