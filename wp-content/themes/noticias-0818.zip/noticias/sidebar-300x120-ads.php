<?php 
echo do_shortcode('<div style="position:relative;left:10px;">
[doap_spacer size="5"]
<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-1-300x120 -->
<div id="div-gpt-ad-1403222233029-0" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-0"); });
</script>
</div>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-2-300x120 -->
<div id="div-gpt-ad-1403222233029-1" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-1"); });
</script>
</div>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-3-300x120 -->
<div id="div-gpt-ad-1403222233029-2" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-2"); });
</script>
</div>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-4-300x120 -->
<div id="div-gpt-ad-1403222233029-3" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-3"); });
</script>
</div>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-5-300x120 -->
<div id="div-gpt-ad-1403222233029-4" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-4"); });
</script>
</div>
</div>

[doap_spacer size="30"]
</div>'); 
?>
