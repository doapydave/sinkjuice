<div id="middle-home-ad-468x60">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 468x60 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:468px;height:60px"
     data-ad-client="ca-pub-6970273280466483"
     data-ad-slot="8470961064"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({}); 
</script>
</div> 
