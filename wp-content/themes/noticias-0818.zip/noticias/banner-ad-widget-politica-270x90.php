<!-- Politica-Top-270x90 -->
<div id='div-gpt-ad-1403209466030-3' class="toprightad">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403209466030-3'); });
</script>
</div>
