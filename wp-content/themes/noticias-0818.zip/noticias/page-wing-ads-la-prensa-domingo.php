<!-- La-Prensa-Domingo-Left-160x600px -->
<div id='div-gpt-ad-1403218103157-1' class="leftad">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403218103157-1'); });
</script>
</div>


<!-- La-Prensa-Domingo-Right-160x600px -->
<div id='div-gpt-ad-1403218103157-2' class="rightad">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403218103157-2'); });
</script>
</div>
