<div id="center-home-ad" style="width:468px;height:60;background-color:#369;">
<!-- Portada-boton-1-468x60 -->
<div id='div-gpt-ad-1402513912207-0' style='width:468px; height:60px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1402513912207-0'); });
</script>
</div>
</div>
<style>
#center-home-ad { background-image: url(/wp-content/uploads/sites/2/2014/06/doap-468x601.png); }
</style>
