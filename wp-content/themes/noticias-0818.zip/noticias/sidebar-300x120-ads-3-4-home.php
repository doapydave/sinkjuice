<?php 
echo do_shortcode('<div style="position:relative;">

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-2-300x120 -->
<div id="div-gpt-ad-1403222233029-1" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-1"); });
</script>
</div>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<!-- Portada-boton-3-300x120 -->
<div id="div-gpt-ad-1403222233029-2" style="width:300px; height:120px;">
<script type="text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1403222233029-2"); });
</script>
</div>
</div>

[doap_spacer size="5"]


</div>'); 
?>
