
<div id="politica-left-top-728-loggedin" class="doaplefttop" title=""Hiding ads to save bandwidth."> </div>

<div style="clear:both;"></div>

<div id="politica-right-top-270-loggedin" class="doaprighttop" title="Hiding ads to save bandwidth."> </div>
