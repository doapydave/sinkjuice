<div style="margin-top:10px;margin-bottom:10px;margin-left:10px;border:1px solid #000;background-color:#eee;width:300px;height:250px;" id="box-loggedin-300x250"></div>
