<?php if ( in_category( 'nacionales' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Nacionales-Top-728x90px', [728, 90], 'div-gpt-ad-1403196057127-0').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Nacionales-Top-270x90', [270, 90], 'div-gpt-ad-1403203008472-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nacionales-Left-160x600px', [160, 600], 'div-gpt-ad-1403196624432-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nacionales-Right-160x600px', [160, 600], 'div-gpt-ad-1403196955810-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nacionales-Top-300x250px', [300, 250], 'div-gpt-ad-1403201478352-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nacionales-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211182544-0').addService(googletag.pubads());
               	googletag.defineSlot('/11648707/Nacionales-bottom-728x90px', [728, 90], 'div-gpt-ad-1403197158457-0').addService(googletag.pubads()); 
		googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'deportes' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Deportes-Top-728x90px', [728, 90], 'div-gpt-ad-1403202333789-5').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Deportes-Top-270x90', [270, 90], 'div-gpt-ad-1403203008472-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Deportes-Left-160x600px', [160, 600], 'div-gpt-ad-1403202333789-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Deportes-Right-160x600px', [160, 600], 'div-gpt-ad-1403202333789-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Deportes-Top-300x250px', [300, 250], 'div-gpt-ad-1403202333789-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Deportes-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211286576-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Deportes-bottom-728x90px', [728, 90], 'div-gpt-ad-1403202333789-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'politica' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/Politica-Top-728x90px', [728, 90], 'div-gpt-ad-1403209349821-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Politica-Top-270x90', [270, 90], 'div-gpt-ad-1403209466030-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Politica-Left-160x600px', [160, 600], 'div-gpt-ad-1403209466030-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Politica-Right-160x600px', [160, 600], 'div-gpt-ad-1403209466030-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Politica-Top-300x250px', [300, 250], 'div-gpt-ad-1403209466030-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Politica-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211357945-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Politica-bottom-728x90px', [728, 90], 'div-gpt-ad-1403209349821-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>


<?php } elseif  ( in_category( 'economia' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/Economia-Top-728x90px', [728, 90], 'div-gpt-ad-1403210392163-6').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Economia-Top-270x90', [270, 90], 'div-gpt-ad-1403210392163-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Economia-Left-160x600px', [160, 600], 'div-gpt-ad-1403210392163-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Economia-Right-160x600px', [160, 600], 'div-gpt-ad-1403210392163-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Economia-Top-300x250px', [300, 250], 'div-gpt-ad-1403210392163-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Economia-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211432106-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Economia-bottom-728x90px', [728, 90], 'div-gpt-ad-1403210392163-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'internacionales' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Internacionales-Top-728x90px', [728, 90], 'div-gpt-ad-1403211824932-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Internacionales-Top-270x90', [270, 90], 'div-gpt-ad-1403211824932-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Internacionales-Left-160x600px', [160, 600], 'div-gpt-ad-1403211824932-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Internacionales-Right-160x600px', [160, 600], 'div-gpt-ad-1403211824932-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Internacionales-Top-300x250px', [300, 250], 'div-gpt-ad-1403211824932-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Internacionales-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403211824932-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Internacionales-bottom-728x90px', [728, 90], 'div-gpt-ad-1403211824932-0').addService(googletag.pubads());	
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'espectaculo' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/Espectaculo-Top-728x90px', [728, 90], 'div-gpt-ad-1403212557668-6').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Espectaculo-Top-270x90', [270, 90], 'div-gpt-ad-1403212557668-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Espectaculo-Left-160x600px', [160, 600], 'div-gpt-ad-1403212557668-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Espectaculo-Right-160x600px', [160, 600], 'div-gpt-ad-1403212557668-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Espectaculo-Top-300x250px', [300, 250], 'div-gpt-ad-1403212557668-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Espectaculo-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403212557668-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Espectaculo-bottom-728x90px', [728, 90], 'div-gpt-ad-1403212557668-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'salud' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/Salud-Top-728x90px', [728, 90], 'div-gpt-ad-1403213428788-6').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Salud-Top-270x90', [270, 90], 'div-gpt-ad-1403213428788-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Salud-Left-160x600px', [160, 600], 'div-gpt-ad-1403213428788-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Salud-Right-160x600px', [160, 600], 'div-gpt-ad-1403213428788-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Salud-Top-300x250px', [300, 250], 'div-gpt-ad-1403213428788-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Salud-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403213428788-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Salud-bottom-728x90px', [728, 90], 'div-gpt-ad-1403213428788-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'departamentales' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Departamentales-Top-728x90px', [728, 90], 'div-gpt-ad-1403214408507-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Departamentales-Top-270x90', [270, 90], 'div-gpt-ad-1403214408507-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Departamentales-Left-160x600px', [160, 600], 'div-gpt-ad-1403214408507-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Departamentales-Right-160x600px', [160, 600], 'div-gpt-ad-1403214408507-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Departamentales-Top-300x250px', [300, 250], 'div-gpt-ad-1403214408507-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Departamentales-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403214408507-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Departamentales-bottom-728x90px', [728, 90], 'div-gpt-ad-1403214408507-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'tecnologia' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/Tecnologia-Top-728x90px', [728, 90], 'div-gpt-ad-1403214977765-6').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Tecnologia-Top-270x90', [270, 90], 'div-gpt-ad-1403214977765-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Tecnologia-Left-160x600px', [160, 600], 'div-gpt-ad-1403214977765-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Tecnologia-Right-160x600px', [160, 600], 'div-gpt-ad-1403214977765-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Tecnologia-Top-300x250px', [300, 250], 'div-gpt-ad-1403214977765-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Tecnologia-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403214977765-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Tecnologia-bottom-728x90px', [728, 90], 'div-gpt-ad-1403214977765-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'ciencia' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Ciencia-Top-728x90px', [728, 90], 'div-gpt-ad-1403215623465-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Ciencia-Top-270x90', [270, 90], 'div-gpt-ad-1403215623465-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Ciencia-Left-160x600px', [160, 600], 'div-gpt-ad-1403215623465-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Ciencia-Right-160x600px', [160, 600], 'div-gpt-ad-1403215623465-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Ciencia-Top-300x250px', [300, 250], 'div-gpt-ad-1403215623465-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Ciencia-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403215623465-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Ciencia-bottom-728x90px', [728, 90], 'div-gpt-ad-1403215623465-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'opinion' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Opinion-Top-728x90px', [728, 90], 'div-gpt-ad-1403216210679-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Opinion-Top-270x90', [270, 90], 'div-gpt-ad-1403216210679-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Opinion-Left-160x600px', [160, 600], 'div-gpt-ad-1403216210679-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Opinion-Right-160x600px', [160, 600], 'div-gpt-ad-1403216210679-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Opinion-Top-300x250px', [300, 250], 'div-gpt-ad-1403216210679-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Opinion-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403216210679-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Opinion-bottom-728x90px', [728, 90], 'div-gpt-ad-1403216210679-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'nosotras' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/Nosotras-Top-728x90px', [728, 90], 'div-gpt-ad-1403217113344-6').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nosotras-Top-270x90', [270, 90], 'div-gpt-ad-1403217113344-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nosotras-Left-160x600px', [160, 600], 'div-gpt-ad-1403217113344-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nosotras-Right-160x600px', [160, 600], 'div-gpt-ad-1403217113344-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nosotras-Top-300x250px', [300, 250], 'div-gpt-ad-1403217113344-5').addService(googletag.pubads())
		googletag.defineSlot('/11648707/Nosotras-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403217113344-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Nosotras-bottom-728x90px', [728, 90], 'div-gpt-ad-1403217113344-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'aqui entre nos' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Aqui-entre-nos-Top-728x90px', [728, 90], 'div-gpt-ad-1403217573777-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Aqui-entre-nos-Top-270x90', [270, 90], 'div-gpt-ad-1403217573777-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Aqui-entre-nos-Left-160x600px', [160, 600], 'div-gpt-ad-1403217573777-1').addService(googletag.pubads());	
		googletag.defineSlot('/11648707/Aqui-entre-nos-Right-160x600px', [160, 600], 'div-gpt-ad-1403217573777-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Aqui-entre-nos-Top-300x250px', [300, 250], 'div-gpt-ad-1403217573777-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Aqui-entre-nos-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403217573777-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Aqui-entre-nos-bottom-728x90px', [728, 90], 'div-gpt-ad-1403217573777-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'la prensa domingo' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
                googletag.defineSlot('/11648707/La-Prensa-Domingo-Top-728x90px', [728, 90], 'div-gpt-ad-1403218103157-6').addService(googletag.pubads());
		googletag.defineSlot('/11648707/La-Prensa-Domingo-Top-270x90', [270, 90], 'div-gpt-ad-1403218103157-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/La-Prensa-Domingo-Left-160x600px', [160, 600], 'div-gpt-ad-1403218103157-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/La-Prensa-Domingo-Right-160x600px', [160, 600], 'div-gpt-ad-1403218103157-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/La-Prensa-Domingo-Top-300x250px', [300, 250], 'div-gpt-ad-1403218103157-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/La-Prensa-Domingo-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403218103157-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/La-Prensa-Domingo-bottom-728x90px', [728, 90], 'div-gpt-ad-1403218103157-0').addService(googletag.pubads());
		googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'empresariales' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Empresariales-Top-728x90px', [728, 90], 'div-gpt-ad-1403219117065-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Empresariales-Top-270x90', [270, 90], 'div-gpt-ad-1403219117065-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Empresariales-Left-160x600px', [160, 600], 'div-gpt-ad-1403219117065-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Empresariales-Right-160x600px', [160, 600], 'div-gpt-ad-1403219117065-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Empresariales-Top-300x250px', [300, 250], 'div-gpt-ad-1403219117065-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Empresariales-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403219117065-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Empresariales-bottom-728x90px', [728, 90], 'div-gpt-ad-1403219117065-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'promociones' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Promociones-Top-728x90px', [728, 90], 'div-gpt-ad-1403219444117-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Promociones-Top-270x90', [270, 90], 'div-gpt-ad-1403219444117-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Promociones-Left-160x600px', [160, 600], 'div-gpt-ad-1403219444117-1').addService(googletag.pubads())
		googletag.defineSlot('/11648707/Promociones-Right-160x600px', [160, 600], 'div-gpt-ad-1403219444117-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Promociones-Top-300x250px', [300, 250], 'div-gpt-ad-1403219444117-5').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Promociones-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403219444117-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Promociones-bottom-728x90px', [728, 90], 'div-gpt-ad-1403219444117-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'productos' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Productos-Top-728x90px', [728, 90], 'div-gpt-ad-1403219821993-6').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Productos-Top-270x90', [270, 90], 'div-gpt-ad-1403219821993-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Productos-Left-160x600px', [160, 600], 'div-gpt-ad-1403219821993-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Productos-Left-160x600px', [160, 600], 'div-gpt-ad-1403219821993-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Productos-Top-300x250px', [300, 250], 'div-gpt-ad-1403220432698-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Productos-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403220432698-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Productos-bottom-728x90px', [728, 90], 'div-gpt-ad-1403219821993-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>

<?php } elseif  ( in_category( 'contactanos' ) ) {?>

        <script type="text/javascript">
                googletag.cmd.push(function() {
		googletag.defineSlot('/11648707/Contactenos-Top-728x90px', [728, 90], 'div-gpt-ad-1403220146418-5').addService(googletag.pubads());
                googletag.defineSlot('/11648707/Contactenos-Top-270x90', [270, 90], 'div-gpt-ad-1403220146418-3').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Contactenos-Left-160x600px', [160, 600], 'div-gpt-ad-1403220508296-0').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Contactenos-Right-160x600px', [160, 600], 'div-gpt-ad-1403220146418-1').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Contactenos-Top-300x250px', [300, 250], 'div-gpt-ad-1403220146418-4').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Contactenos-Sidebar-300x250px', [300, 250], 'div-gpt-ad-1403220146418-2').addService(googletag.pubads());
		googletag.defineSlot('/11648707/Contactenos-bottom-728x90px', [728, 90], 'div-gpt-ad-1403220146418-0').addService(googletag.pubads());
                googletag.pubads().enableSingleRequest();
                googletag.enableServices();
                });
        </script>


<?php } else { ?>

<script type='text/javascript'>
googletag.cmd.push(function() {
    
/* home slots */
googletag.defineSlot('/11648707/Portada-Top-728x90', [728, 90], 'div-gpt-ad-1403199951031-2').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Top-270x90', [270, 90], 'div-gpt-ad-1403223429448-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Top-300x250px', [300, 250], 'div-gpt-ad-1403198971774-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Bottom-728x90', [728, 90], 'div-gpt-ad-1403199951031-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Left-160x600', [160, 600], 'div-gpt-ad-1403200779714-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Right-160x600', [160, 600], 'div-gpt-ad-1403200779714-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Middle-728x90', [728, 90], 'div-gpt-ad-1403199951031-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/120x600-Top', [120, 600], 'div-gpt-ad-1403371468819-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-Bottom-300x250px', [300, 250], 'div-gpt-ad-1403198971774-0').addService(googletag.pubads());

/* if ads on single */
googletag.defineSlot('/11648707/Nacionales-Top-300x250px', [300, 250], 'div-gpt-ad-1403201478352-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Deportes-Top-300x250px', [300, 250], 'div-gpt-ad-1403202333789-4').addService(googletag.pubads());
googletag.defineSlot('/11648707/Internacionales-Top-300x250px', [300, 250], 'div-gpt-ad-1403211824932-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Espectaculo-Top-300x250px', [300, 250], 'div-gpt-ad-1403212557668-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Economia-Top-300x250px', [300, 250], 'div-gpt-ad-1403210392163-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Politica-Top-300x250px', [300, 250], 'div-gpt-ad-1403209466030-4').addService(googletag.pubads());
googletag.defineSlot('/11648707/Salud-Top-300x250px', [300, 250], 'div-gpt-ad-1403213428788-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Departamentales-Top-300x250px', [300, 250], 'div-gpt-ad-1403214408507-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Tecnologia-Top-300x250px', [300, 250], 'div-gpt-ad-1403214977765-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Ciencia-Top-300x250px', [300, 250], 'div-gpt-ad-1403215623465-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Opinion-Top-300x250px', [300, 250], 'div-gpt-ad-1403216210679-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Nosotras-Top-300x250px', [300, 250], 'div-gpt-ad-1403217113344-5').addService(googletag.pubads())
googletag.defineSlot('/11648707/Aqui-entre-nos-Top-300x250px', [300, 250], 'div-gpt-ad-1403217573777-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/La-Prensa-Domingo-Top-300x250px', [300, 250], 'div-gpt-ad-1403218103157-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Empresariales-Top-300x250px', [300, 250], 'div-gpt-ad-1403219117065-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Promociones-Top-300x250px', [300, 250], 'div-gpt-ad-1403219444117-5').addService(googletag.pubads());
googletag.defineSlot('/11648707/Productos-Top-300x250px', [300, 250], 'div-gpt-ad-1403220432698-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Contactenos-Top-300x250px', [300, 250], 'div-gpt-ad-1403220146418-4').addService(googletag.pubads());


/* botones 1-5 sidebar slots */
googletag.defineSlot('/11648707/Portada-boton-1-300x120', [300, 120], 'div-gpt-ad-1403222233029-0').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-boton-2-300x120', [300, 120], 'div-gpt-ad-1403222233029-1').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-boton-3-300x120', [300, 120], 'div-gpt-ad-1403222233029-2').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-boton-4-300x120', [300, 120], 'div-gpt-ad-1403222233029-3').addService(googletag.pubads());
googletag.defineSlot('/11648707/Portada-boton-5-300x120', [300, 120], 'div-gpt-ad-1403222233029-4').addService(googletag.pubads());

googletag.pubads().enableSingleRequest();
googletag.enableServices();
});
</script>

<?php } ?>
