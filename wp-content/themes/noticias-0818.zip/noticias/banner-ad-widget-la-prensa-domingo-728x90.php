<!-- La-Prensa-Domingo-Top-728x90px -->
<div id='div-gpt-ad-1403218103157-6' class="topleftad">
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1403218103157-6'); });
</script>
</div>
