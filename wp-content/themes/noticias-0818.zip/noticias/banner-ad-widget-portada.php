<div style="clear:both;"></div>
<div class="topad" id="div-gpt-ad-1399587327178-0" style="left:-3px;z-index:0;width:728px;height:90px;position:relative;float:left;margin-top:4px;background-color:#369;"></div>
<div style="clear:both;"></div>

