<?php 
echo do_shortcode('<div style="position:relative;">
[doap_spacer size="5"]
<div style="height:120px;width:300px;background-color:#369;">
<iframe src="http://laprensa11.doap.us/ads/budgets.html" height="120" width="300" frameborder="0" scrolling="none"></iframe>
<!-- Portada-boton-1-300x120 -->
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<iframe src="http://laprensa11.doap.us/ads/prensaclub.html" height="120" width="300" frameborder="0" scrolling="none"></iframe>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<iframe src="http://laprensa11.doap.us/ads/suscripciones.html" height="120" width="300" frameborder="0" scrolling="none"></iframe>
</div>

[doap_spacer size="5"]

<div style="height:120px;width:300px;background-color:#369;">
<iframe src="http://laprensa11.doap.us/ads/comtech.html" height="120" width="300" frameborder="0" scrolling="none"></iframe>
</div>

[doap_spacer size="30"]
</div>'); 
?>
