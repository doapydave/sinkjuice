Shortcodes Ultimate: Skins add-on
==================================

Set of additional skins for shortcodes from Shortcodes Ultimate. [Visit project page](http://gndev.info/shortcodes-ultimate/skins/).

Requirements
------------

* PHP 5.1 or higher
* WordPress 3.5 or higher
* Shortcodes Ultimate 4.4 or higher

Changelog
=========

1.3.4
-----
* Added source files links to the settings page

1.3.3
-----
* Added customer support link to plugin meta

1.3.2
-----
* Added NL locale

1.3
---
* Updated examples

1.0
---
* Initial release